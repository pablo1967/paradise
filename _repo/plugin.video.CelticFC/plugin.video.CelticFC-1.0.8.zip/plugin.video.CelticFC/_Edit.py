import xbmcaddon

MainBase = 'https://goo.gl/jHhmcs'
addon = xbmcaddon.Addon('plugin.video.CelticFC')