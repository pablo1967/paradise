'''
    Copyright (C) 2017 THFC Zone,BigYidBuilds

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import urllib
import urllib2
import datetime
import re
import os
import base64
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import cookielib
import time
import requests
import sys
from lib.modules import getUrl,addDir,resolve
addonInfo = xbmcaddon.Addon().getAddonInfo
home = xbmc.translatePath(addonInfo('path'))
FANART = os.path.join(home, 'fanart.jpg')


def sky_vid_scrape(name,url):
	html = getUrl.getUrl('http://www.skysports.com/celtic-videos', cookieJar=None,post=None, timeout=20, headers=None)
	match = re.compile('<div class="polaris-tile__media-wrap">(.+?)<h2 class="polaris-tile__heading">(.+?)</h2>',re.DOTALL).findall(html)
	for a,b in match:
		c = a+b
		match = re.compile('data-src="(.+?)".+?<a href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(str(c))
		for icon,pageurl,pagename in match:
			name = pagename.strip()
			pageurl = 'http://www.skysports.com'+pageurl
			Html = getUrl.getUrl(pageurl, cookieJar=None,post=None, timeout=20, headers=None)
			Match = re.compile('data-video-id="(.+?)".+?<p class="sp-player__summary">(.+?)</p>',re.DOTALL).findall(Html)
			for vidID,info in Match:
				url = 'http://video.skysports.com/'+vidID+'/'+vidID+'_1.f4m'
				f = urllib.urlopen(url)
				fullpage = f.read()
				if '<drmAdditionalHeader drmContentId=' not in fullpage:
					addDir.addDir_file(name,url,2001,icon,FANART,info,'','','')

				
				


	
